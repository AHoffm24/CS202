#include <iostream>
#include "circleCylinder.h"
#include <iomanip>
using namespace std;

int main()
{
double radius = 0.0;
double height = 0.0;
double shipPerLiter = 0.0;
double costSqFt = 0.0;
double totalship = 0.0;
double totalpaint = 0.0;
double total = 0.0;
bool info1 = false;
bool info2 = false;
while(info1 == false || info2 == false)
{
        if(info1 == false)
        cout << "Enter the radius of the base of the"
        << " cylinder and the height(in feet)" << endl;
        cin >> radius >> height;
        if (cin.fail() == true)
        {
           cin.clear();
           cin.ignore(100, '\n');
        }
        else
        info1 = true;

    if (info1 == true)
    {
        cout << "Enter  shipping  cost  per  liter"
        << "and  paint  cost  per  square  foot"
        <<  endl;
        cin >> shipPerLiter >> costSqFt;
        if (cin.fail() == true)
        {
           cin.clear();
           cin.ignore(100, '\n');
        }
        else
        info2 = true;
    }
}

circle   c1(radius);
cylinder c2(radius, height);
totalpaint = c2.area() * costSqFt;
totalship = c2.volume() * shipPerLiter * 28.32;
total = totalpaint + totalship;

cout << setfill('.') << setw(29) << left << "Price To ship Container" << "$"
     << setfill(' ') << setw(10) << right << fixed << setprecision(2)
     << totalship << endl;

cout << setfill('.') << setw(29) << left << "Price to paint container"<< "$"
     << setfill(' ') << setw(10) << right << setprecision(2)
     << totalpaint << endl;

cout << setfill('.') << setw(29) << left << "Toal Cost"
     << "$"  << setfill(' ') << setw(10) << right << setprecision(2)
     << total << endl;

   return 0;
}
